
package calculadora;
public class Operaciones {
    //Atributos
    protected double nro1;
    protected double nro2;
    //Propiedades
    public double getNro1()
    {
        return this.nro1;
    }
    public double getNro2() {
        return this.nro2;
    }
    public void setNro1(double nro1) 
    {
        this.nro1 = nro1;
    }
    public void setNro2(double nro2) 
    {
        this.nro2 = nro2;
    }
    //Constructores
    // 1.-Constructores sin sobrecargas de parametros
    public Operaciones()
    {}
    // 2.-Constructores con sobrecarga de parametros
    public Operaciones(double nro1,double nro2)
    {
        this.nro2 = nro2;
        this.nro2 = nro2;
    }
    //Implementacion de metodos u operaqciones
    public double Sumar()
    {
        return this.nro1 + this.nro2;   
    }
    public double Restar()
    {
        return this.nro1 - this.nro2;   
    }
    public double Multiplicar()
    {
        return this.nro1 * this.nro2;   
    }
    public String  Dividir()
    {
        if(this.nro2 == 0){
            return "Error: Division entre 0";
        }
        else
        {
            double divide = this.nro1 / this.nro2;
            return String.valueOf(divide);
        }
    }
    public double Potencia()
    {
        double Pot = 1;
        for (int i = 1;i <=this.nro2;i++){
            Pot *=this.nro1;
        }
        return Pot;
    }
    private double Fact(double nro)
    {
        if (nro==0) {
           return 1;
        }
        else
            return nro * Fact(nro-1);
    }
    public double Factorial()
    {
        return Fact(this.nro1);
    }
    public double Raiz()
    {
        return Math.sqrt(this.nro1);
    }
    public double Seno()
    {
        return Math.sin(Math.toRadians(this.nro1));
    }
    public double Coseno()
    {
        return Math.cos(Math.toRadians(this.nro1));
    }
    public double Tangente()
    {
        return Math.tan(Math.toRadians(this.nro1));
    }  
}

