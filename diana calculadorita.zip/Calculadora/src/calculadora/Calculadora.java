
package calculadora;
import Formulario.newpackage.frmCalculadora;
public class Calculadora {
    public static void main(String[] args) {
        frmCalculadora frm = new frmCalculadora();
        frm.setVisible(true);
    }
}
